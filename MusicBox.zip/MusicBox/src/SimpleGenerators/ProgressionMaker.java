package SimpleGenerators;
import java.util.Random;
/**
 * A program that randomly generates a chord progression of a given length
 * for a specified key.
 * @author Stephen Bondurich
 * Sep 20, 2018
 *
 */
public class ProgressionMaker {

	private ChordsMaker chords = new ChordsMaker();
	
	private String keyTonic;
	
	private Random posgen = new Random();
	
	private void setKeyTonic(String root) {
		this.keyTonic = root;	
	}
	
	/**
	 * @return a string array containing the chords for the key
	 */
	private String[] getChords() {
		chords.setScale(keyTonic);
		chords.generateChords();
		return chords.getchordsList();
	}
	
	/**
	 * 
	 * @param chords The possible chords to choose from
	 * @param length The length of the progression
	 */
	private void generateProgression(String[] chords, int length) {
		int lastpos = -1;
		//makes it so lastpos will never equal position on the first iteration
		//lastpos is there to prevent two of the same chord in a row
		int chordCount = 0;
		while (chordCount<length) {
			int position = posgen.nextInt(7);
			if (position != lastpos) {
			System.out.print(chords[position]+" ");
			lastpos = position;
			chordCount++;
			}
		}
		
	}// creates a random chord progression of specified length
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProgressionMaker cake = new ProgressionMaker();
		cake.setKeyTonic("bb");
		cake.generateProgression(cake.getChords(), 8);
	}

}
