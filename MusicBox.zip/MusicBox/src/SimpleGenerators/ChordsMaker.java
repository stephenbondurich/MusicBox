package SimpleGenerators;

import java.util.Arrays;

/**
 * A program that generates the chords found in a given major scale.
 * @author stephenbondurich
 *
 */

public class ChordsMaker {

	private ScaleMaker scale;
	private String[] chordsList = new String[6];
	
	public ScaleMaker getScale() {
		return scale;
	}
	
	public String[] getchordsList() {
		return chordsList;
	}
	
	public void setScale(String tonic) {
		
		this.scale = new ScaleMaker(tonic);
	}
	
	public void generateChords() {
		String[] scalenotes = scale.generateMajorScale();
		
		chordsList = Arrays.copyOf(scalenotes, 7);
		
		for (int i = 0; i<scalenotes.length; i++) {
			if (i == 1 || i == 2 || i == 5) {
				chordsList[i] +="m";
			}// creates minor chords
			if (i==6) {
				chordsList[i] += "dim";
			}//creates the diminished chord
		}
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		ChordsMaker cake = new ChordsMaker();
		cake.setScale("eb");
		cake.generateChords();
		System.out.println(Arrays.toString(cake.getchordsList()));
		
		
		

	}

}
