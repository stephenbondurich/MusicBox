package SimpleGenerators;

import java.util.Arrays;

/**
 * A program that takes a tonic note as input and produces the seven
 * notes in the tonic's major scale, in order.
 * 
 * Note: by convention, a lower case "b" is appended to a note instead
 * of the actual flat symbol to indicate that the key/note is flat.
 * @author stephenbondurich
 *
 */
public class ScaleMaker {
	
	private  String[] keyC = 
		{"C", "D", "E", "F", "G", "A", "B"};
	// initializes the key of C
	
	private String[] flatTonics = {"f", "Bb", "Eb", "Ab", "Db"};
	// dictates which notes use flats instead of sharps
	
	private String tonic;
	
	
	/**
	 * 
	 * @param tonic  The tonic note of the desired key
	 */
	public ScaleMaker (String tonic) {
		this.tonic = tonic;
	}
	
	/**
	 * Generates a major scale for the current instance's tonic
	 * @return String array of notes in the key, in order.
	 */
	public String[] generateMajorScale() {
		
		String[] newscale = Arrays.copyOf(keyC,7);
		String[] lastscale = Arrays.copyOf(newscale, 7);
		boolean flatkey = false;
		
		for (String note: flatTonics) {
			if (tonic.equalsIgnoreCase(note)) {
				flatkey = true;
				break;
			}
		}
		//determines whether the scale will include sharps or flats
		
		if (flatkey) {
			while (!tonic.equalsIgnoreCase(newscale[0])){
				
				newscale[0] = lastscale[3];
				newscale[1] = lastscale[4];
				newscale[2] = lastscale[5];
				newscale[3] = lastscale[6]+"b";
				newscale[4] = lastscale[0];
				newscale[5] = lastscale[1];
				newscale[6] = lastscale[2];
				
				lastscale = Arrays.copyOf(newscale, 7);
	
			}
		}
		
		// creates scale with flat accents
		else {
		
		while (!tonic.equalsIgnoreCase(newscale[0])) {
			
			newscale[0] = lastscale[4];
			newscale[1] = lastscale[5];
			newscale[2] = lastscale[6];
			newscale[3] = lastscale[0];
			newscale[4] = lastscale[1];
			newscale[5] = lastscale[2];
			newscale[6] = lastscale[3]+"#";
			
			lastscale = Arrays.copyOf(newscale, 7);	
			
		}
		}// creates scale with sharp accents
		
		return newscale;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
